---
title: Analyse des besoins - Flux principaux
---

# Flux principaux

## Objectif

Décrire les flux d’interaction entre les acteurs et le système.

## Diagrammes

TODO: Insérer ici des diagrammes d'activités

### Description des flux complexes

