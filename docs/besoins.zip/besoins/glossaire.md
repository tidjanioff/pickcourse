---
title: Analyse des besoins - Glossaire
---

# Glossaire

Ce glossaire définit les termes importants utilisés dans le projet, en particulier ceux qui pourraient prêter à confusion.

| Terme | Définition |
|-------|------------|
| Centre étudiant | Définition du terme 1 |
| cheminement type | Définition du terme 2 |
| programme | Définition du terme 2 |
| discord | Définition du terme 2 |
| ratemyprofessor | Définition du terme 2 |
| reddit | Définition du terme 2 |
| étudiant international | Définition du terme 2 |
| retour aux études | Définition du terme 2 |
| crédits | Définition du terme 2 |
| gpa | Définition du terme 2 |
| plan de cours | Définition du terme 2 |
| tableaux de bord? | Définition du terme 2 |
| agrégés | mis ensemble, combinés | ( je pense pas que ça fasse partie du glossaire)
