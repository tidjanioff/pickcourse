---
title: Analyse des besoins - Présentation générale
---

# Présentation du projet

## Méthodologie pour la cueillette des données

TODO: Préciser comment les besoins ont été collectés (entrevues, questionnaires, brainstorming, etc.).

## Description du domaine

### Fonctionnement

Domaine = toutes les entités qui interviennent lors du choix de cours à l'udem?

Le domaine de ce projet constitue un grand ensemble, au coeur duquel se trouvent les étudiants de l'université de Montréal, qui représentent d'ailleurs la cible principale de ce dernier.

 A l'UdeM, le choix de cours est très souvent basé sur les **descriptions détaillées** données sur le *site officiel de l'université*, parfois sur les **descriptions courtes** données sur le *Centre Étudiant*. Les plus inquiets auront tendance à faire plus de recherches, et utiliseront bien souvent des ressources comme **les avis d'anciens étudiants** au sein de *groupes Discord*( comme *l'AEDIROUM* pour les étudiants en informatique ou encore *AGÉÉPUM* pour les étudiants en psychologie), **des recherches Internet** ( ratemyprofessor, reddit). Certains peuvent également solliciter l'aide de **TGDEs** ou de **conseillers**, qui peuvent aussi bien être des responsables que des camarades qui ont déjà fait le cours ( bouche-à-oreille). Tous ces éléments gravitent dans notre domaine, et assurent le fonctionnement de ce dernier.

### Acteurs

Le domaine tel que décrit ci-dessus renferme de nombreux acteurs. En avant-première, nous avons :

- Les étudiants de l'université de Montréal. Cette catégorie concerne aussi bien les anciens étudiants ( ceux qui ont déjà eu des cours) que les nouveaux( ceux qui souhaitent s'inscrire pour la première fois à des cours à l'UdeM, ils peuvent provenir de cégeps, d'autres pays, d'autres universités). Dans cette catégorie, on retrouve également des étudiants qui ont déjà eu le cours en question auquel l'étudiant x veut s'inscrire, et qui fournissent les ressources non-officielles( Discord, reddit, bouche-à-oreille, et autres ) dont ce dernier se sert.

- Les responsables : Il s'agit ici de TGDEs et de conseillers qui guident les étudiants dans leur prise de décisions. Les conseillers pourraient aussi bien être des conseillers d'orientation que les profs chargés de cours qui peuvent aider l'étudiant à comprendre s'il satisfait aux exigences du cours.

- Les chargés de cours : Les professeurs, ainsi que les démonstrateurs représentent également des acteurs de notre domaine car ils sont justement responsables des cours en question.

### Dépendances

Il existe des dépendances entre les étudiants et tous les autres acteurs, et également entre les étudiants.

## Hypothèses et contraintes

TODO: Liste des hypothèses de travail et des contraintes (techniques, organisationnelles, etc.).

Ma première hypothèse est: "les acteurs sont les acteurs du domaine et non du "projet". S'il s'agissait de la deuxième catégorie, on aurait beaucoup plus d'acteurs( par exemple les robots Discord qui vont collecter les données pour implémenter la fonctionnalité de répertoire d'avis non-officiels, ou encore Planifium?( vu qu'on a dit que tout ce qui interagit avec le système est un acteur mais c'est probablement un peu trop abstrait)) "
